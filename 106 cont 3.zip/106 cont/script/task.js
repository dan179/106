// classes

class Task {
    constructor(important, title, dueDate, contact, location, desc, color) {
        this.important = important;
        this.title = title;
        this.dueDate = dueDate;
        this.contact = contact;
        this.location = location;
        this.desc = desc;
        this.color = color;

        this.name = "Danielt48"

    }
}